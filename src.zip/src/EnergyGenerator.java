public class EnergyGenerator {
}
