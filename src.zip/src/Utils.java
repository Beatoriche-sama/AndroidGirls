import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.Random;

public class Utils {

    public static String giveMeName(){
        String [] names = {"Lily", "Hanako", "Rin", "Emmy", "Shizune", "Misha"};
        int idx = new Random().nextInt(names.length);
        return (names[idx]);
    }

    public static String giveMeInfo(){
        Random random = new Random();
        String [] info1 = {"Wants", "Loves", "Dreams about", "Singing about"};
        String [] info2 = {"sweet", "magical", "hentai", "brave"};
        String [] info3 = {"castle", "kitten", "book", "cutlets"};

        int ind1 = random.nextInt(info1.length);
        int ind2 = random.nextInt(info2.length);
        int ind3 = random.nextInt(info3.length);
        return (info1[ind1] + " " + info2[ind2] + " " + info3[ind3] + ".");
    }

    public static int giveMeicon(){
        Random rand = new Random();
        return rand.nextInt((5 - 1) + 1) + 1;
    }

    public static BufferedImage getScaledImage(Image srcImg, int w, int h) {
        BufferedImage resizedImg = new BufferedImage(w, h, BufferedImage.TRANSLUCENT);
        Graphics2D g2 = resizedImg.createGraphics();
        g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        g2.drawImage(srcImg, 0, 0, w, h, null);
        g2.dispose();
        return resizedImg;
    }

}
