import javax.swing.*;
import java.util.ArrayList;
import java.util.concurrent.atomic.AtomicInteger;

public class GroupNumberModel extends SpinnerNumberModel {
    private JLabel freeLabelCount;
    private ArrayList<Android> freeList;
    ArrayList<CustomSpinner> spinners;
    DefaultListModel<Android> jlistModel;

    public GroupNumberModel() {
        spinners = new ArrayList<>();
    }

    public void addSpinner(CustomSpinner spinner) {
        spinners.add(spinner);
    }

    private CustomSpinner getSpinner(ArrayList<Android> androids){
       return spinners.stream()
                .filter(spinner-> spinner.getJobList() == androids).findAny().orElse(null);
    }

    public void updateComponent(ArrayList<Android> androids) {
        int newValue = androids.size();
        if (androids.equals(freeList)) freeLabelCount
                .setText(String.valueOf(newValue));
        else {
            CustomSpinner spinner = getSpinner(androids);
            SpinnerNumberModel numberModel = (SpinnerNumberModel) spinner.getModel();
            numberModel.setValue(newValue);
        }
    }

    public int getCommonValue() {
        AtomicInteger i = new AtomicInteger();
        spinners.forEach(spinner -> i.set((Integer) spinner.getValue() + i.get()));
        return i.get();
    }

    public JLabel getFreeLabelCount() {
        return freeLabelCount;
    }

    public ArrayList<Android> getFreeList() {
        return freeList;
    }

    public DefaultListModel<Android> getJlistModel() {
        return jlistModel;
    }

    public void setFreeLabelCount(JLabel freeLabelCount) {
        this.freeLabelCount = freeLabelCount;
    }

    public void setFreeList(ArrayList<Android> freeList) {
        this.freeList = freeList;
    }

    public void setJlistModel(DefaultListModel<Android> jlistModel) {
        this.jlistModel = jlistModel;
    }
}
