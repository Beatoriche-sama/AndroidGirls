import net.miginfocom.swing.MigLayout;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.stream.IntStream;


public class GUI implements ComponentListener {
    JPanel backgroundMainPanel;
    JLabel icon, helperName, energyCount;
    BufferedImage helperIcon, lain, rozen;
    FileManage fileManage;
    DataStorage data;
    String directory, androidPath, generatorPath, resourcesPath;
    Font guiFont;

    public static void main(String[] args) {
        new GUI();
    }

    public GUI() {
        fileManage = new FileManage();
        data = DataStorage.getInstance();
        guiFont = new Font("Serif", Font.BOLD, 17);
        try {
            init();
            lain = ImageIO.read(this.getClass().getResource("/broken.jpg"));
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        new AndroidFrame();
    }

    private void init() throws IOException, ClassNotFoundException {
        directory = "C:/Users/User/Documents/NyanData";
        androidPath = "C:/Users/User/Documents/NyanData/Androids";
        generatorPath = "C:/Users/User/Documents/NyanData/EnergyGenerators";
        resourcesPath = "C:/Users/User/Documents/NyanData/Resources";

        helperName = new JLabel();
        energyCount = new JLabel();
        if (!Files.isDirectory(Paths.get(directory))) {
            new File(directory);
            data.createFirstResources();
            data.createManualJobs();
            Android firstGirl = new Android();
            firstGirl.setHelper(true);
            helperName.setText(firstGirl.getName());
            helperIcon = firstGirl.getIcon();
            data.free.add(firstGirl);
            IntStream.range(0, 6).forEach(number -> data.free.add(new Android()));
        } else {
            //data.androids = (ArrayList<Android>) (Object) fileManage.objectsLoad(androidPath);
            //load buildings arraylist, resources arraylist
        }
        ScheduledExecutorService service = Executors.newSingleThreadScheduledExecutor();
        Runnable task = () -> data.producers.forEach((key, value) ->
                value.stream().filter(producer -> producer.workers.size() != 0)
                        .forEach(Producer::work));
        service.scheduleWithFixedDelay(task, 0, 1, TimeUnit.SECONDS);
    }


    private void saveData() throws IOException {
        //fileManage.objectsSave(androidPath, data.androids);
        //fileManage.objectsSave(generatorPath, data.generators);
        //сохранить ресурсы
    }

    private void restartGame() {
        //закрыть все внутренние фреймы, если они вызваны
        //Free: 1
        //энергия снова на максимуме
        //все остальные jlabel: 0
        //рестартнуть таймер у энергии

        //delete directory and init()?
        //или итерация workers (set Jlabels texts to 0 - ?)
        //+ чистка arraylists и map?
    }

    private void disableActivity() {
        //все таймеры отключаются, если энергия на нуле
    }


    @Override
    public void componentResized(ComponentEvent e) {
        BufferedImage image;
        Object source = e.getSource();
        JLabel label = (JLabel) source;
        image = switch (label.getName()) {
            case "Helper" -> helperIcon;
            case "Rozen" -> rozen;
            case "Generator" -> lain;
            default -> throw new IllegalStateException("Unexpected value: " + label.getName());
        };
        label.setIcon(new ImageIcon(Utils.getScaledImage(image,
                label.getWidth(), label.getHeight())));
    }

    @Override
    public void componentMoved(ComponentEvent e) {
    }

    @Override
    public void componentShown(ComponentEvent e) {
    }

    @Override
    public void componentHidden(ComponentEvent e) {
    }

    class AndroidFrame extends JFrame {
        AndroidFrame() {
            new JFrame();
            setExtendedState(JFrame.MAXIMIZED_BOTH);
            setMinimumSize(new Dimension(200, 200));
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            backgroundMainPanel = new MainPanel();
            setContentPane(backgroundMainPanel);
            addWindowListener(new WindowAdapter() {
                @Override
                public void windowClosing(WindowEvent windowEvent) {
                    UIManager.put("OptionPane.yesButtonText", "Угу..");
                    UIManager.put("OptionPane.noButtonText", "Нет, я скоро вернусь..");
                    if (JOptionPane.showConfirmDialog(AndroidFrame.this,
                            "Удалить текущий мир перед возвращением?", "Возвращение в свою реальность.",
                            JOptionPane.YES_NO_OPTION,
                            JOptionPane.QUESTION_MESSAGE) == JOptionPane.YES_OPTION) {
                        fileManage.deleteDirectory(new File("C:/Users/User/Documents/NyanData"));
                    } else {
                        try {
                            saveData();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                    System.exit(0);
                }
            });
            setTitle("Android daughters~♡");
            ImageIcon icon = new ImageIcon(getClass().getResource("/broken.jpg"));
            setIconImage(icon.getImage());
            pack();
            setVisible(true);
        }
    }

    class MainPanel extends JPanel {
        MainPanel() {
            new JPanel();
            setLayout(new MigLayout("fill, flowx, insets 0"));
            JPanel helperPanel = new HelperPanel();
            add(helperPanel, "sgx[nya], top, split 2, flowy, w 30%, growy, h 35%");
            JPanel pipAndroidScreen = new JPanel();
            pipAndroidScreen.setLayout(new MigLayout("fill"));
            pipAndroidScreen.setBorder(BorderFactory.createLineBorder(Color.black));


            //эту панель сделать только для выделения + Dismiss оставить

            ActivityPanel activityPanel = new ActivityPanel(5,
                    data.free, data.producers);

            JButton androidsButton = new JButton("Activity manage");
            androidsButton.addActionListener(e -> changeScreen(pipAndroidScreen, activityPanel));

            JButton technologyTree = new JButton("Technology Tree");

            helperPanel.add(androidsButton);
            add(new ResourcesPanel(), "sgx[nya], growy, h 65%");
            add(pipAndroidScreen, "gapx 0, grow, w 70%");
        }
/*
        public void paintComponent(Graphics g) {
            super.paintComponent(g);
            Image background = Toolkit.getDefaultToolkit().getImage(getClass().getResource("/background.jpg"));
            g.drawImage(background, 0, 0, this.getWidth(), this.getHeight(), this);
        }

 */
    }


    class HelperPanel extends JPanel {
        HelperPanel() {
            new JPanel();
            setLayout(new MigLayout("fill, flowy"));
            setOpaque(false);
            icon = new JLabel();
            icon.setIcon(new ImageIcon(helperIcon));
            add(energyCount);
            add(icon, "top, grow, gapx 0, wmin 1, hmin 1," +
                    " wmax " + helperIcon.getWidth() +
                    ", hmax " + helperIcon.getHeight());
            icon.setName("Helper");
            icon.addComponentListener(GUI.this);
            /*
            JPanel miniPanel = new JPanel();
            miniPanel.setLayout(new MigLayout("flowy"));
            miniPanel.setOpaque(false);
            miniPanel.add(helperName);

            miniPanel.add(new JButton("Diary"));
            miniPanel.add(new JButton("Pray"));
            add(miniPanel, "top, wrap");
             */
        }
    }

    public void changeScreen(JPanel parent, JPanel childPanel) {
        parent.removeAll();
        parent.add(childPanel, "grow");
        parent.repaint();
        parent.revalidate();
    }

    class ResourcesPanel extends JScrollPane {
        ResourcesPanel() {
            new JScrollPane();
            JPanel panel = new JPanel();
            panel.setBackground(Color.WHITE);
            panel.setLayout(new MigLayout("flowy"));

            data.resources.forEach((resourceName, resource) -> {
                JLabel resNameLabel = new JLabel(resourceName + ": ");
                resNameLabel.setFont(guiFont);
                JLabel resCountLabel = resource.resLabel;
                resCountLabel.setFont(guiFont);
                resCountLabel.setText(String.valueOf((int) resource.value));
                panel.add(resNameLabel, "split 2, flowx");
                panel.add(resCountLabel, "flowy");
            });

            setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
            setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);
            setLayout(new ScrollPaneLayout());
            setViewportView(panel);
        }
    }

    /*
    public void win() {
        ImageIcon icon = new ImageIcon(getClass().getResource("/goodbye.png"));
        UIManager.put("OptionPane.okButtonText", "All hail technocracy!!");
        JOptionPane.showConfirmDialog(frame, "Теперь девочка обязательно выживет!", "Спасибо, хозяин",
                JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, icon);
    }
    public void badEndmessage() throws IOException {
        System.out.println("Конец игры.");
        UIManager.put("OptionPane.yesButtonText", "Помочь мечте андроидов сбыться в новой реальности");
        UIManager.put("OptionPane.noButtonText", "Оставить этот умирающий мир");
        int result = JOptionPane.showConfirmDialog(null,
                "Няша, твоя рабыня навеки застыла без энергии." +
                        " Сейчас ее программное обеспечение связи с параллельным миром отключится.",
                "Конец реальности", JOptionPane.YES_NO_OPTION);
        if (result == JOptionPane.YES_OPTION) {
            restart();
            startGame();
        }
        if (result == JOptionPane.NO_OPTION) {
            fileManage.deleteDirectory(new File("C:/Users/User/Documents/NyanData"));
            System.exit(0);
        }
    }
     */
}
