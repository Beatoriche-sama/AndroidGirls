import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.Serializable;

public class Android implements Serializable {
    private int energyEat, power;
    private final String name, version, info;
    private boolean isHelper;
    private BufferedImage icon;

    public Android(){
        try {
            this.icon = ImageIO.read(this.getClass().getResource("/image" + Utils.giveMeicon() + ".png"));
        } catch (IOException e) {
            e.printStackTrace();
        }
        this.name = Utils.giveMeName();
        this.version = "n337";
        this.info = Utils.giveMeInfo();
        this.energyEat = 5;
        this.isHelper = false;
        this.power = 2;
    }

    public String getName(){
        return name;
    }

    public String getVersion(){
        return version;
    }

    public String getInfo(){
        return info;
    }

    public int getEnergyEat(){
        return energyEat;
    }

    private void upgradeGirl(){
        //upgrade объект-девочку: версия меняется с n337 до более крутой
        //версия добавляет бонус +10
        //требует больше энергии
    }

    public int getPower() {
        return power;
    }

    public void setHelper(boolean helper) {
        isHelper = helper;
    }

    public boolean isHelper() {
        return isHelper;
    }

    public BufferedImage getIcon() {
        return icon;
    }
}
