public class SingleTaskProducer extends Producer {
    Resource resource;

    public SingleTaskProducer(String producerName, Resource resource){
        this.producerName = producerName;
        this.resource = resource;
    }

    @Override
    public void work() {
        WorkProceeding.converseItem(resource, getAndroidPower());
    }
}
