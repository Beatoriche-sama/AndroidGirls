import java.util.ArrayList;

public class MultipleTasksProducer extends Producer {
    ArrayList<Resource> resources;

    MultipleTasksProducer(String producerName, ArrayList<Resource> resources){
        this.producerName = producerName;
        this.resources = resources;
    }

    @Override
    public void work() {
       WorkProceeding.pickRandomItem(resources, getAndroidPower());
    }
}
