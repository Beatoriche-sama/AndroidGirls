import javax.swing.*;
import java.util.ArrayList;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.IntStream;

public class ListenersHolder {
    private ArrayList<Android> selectedAndroidsList;
    private final JList<Android> jList;
    private final DefaultListModel<Android> jlistModel;
    private final AtomicInteger lastIndex;

    public ListenersHolder(JList<Android> jList) {
        this.jList = jList;
        this.jlistModel = (DefaultListModel<Android>) jList.getModel();
        lastIndex = new AtomicInteger(0);
    }

    public HireListener createHireListener(GroupNumberModel groupNumberModel) {
        return new HireListener(groupNumberModel);
    }

    public ShowListener createShowListener(int maximumElementsPage) {
        return new ShowListener(maximumElementsPage);
    }

    class HireListener {
        private final GroupNumberModel groupNumberModel;

        HireListener(GroupNumberModel groupNumberModel) {
            this.groupNumberModel = groupNumberModel;
        }

        public void setActivity(ArrayList<Android> listTo) {
            if (listTo.equals(selectedAndroidsList)) return;
            jList.getSelectedValuesList().forEach((android -> {
                selectedAndroidsList.remove(android);
                listTo.add(android);
                jlistModel.removeElement(android);
            }));
            groupNumberModel.updateComponent(selectedAndroidsList);
            groupNumberModel.updateComponent(listTo);
            lastIndex.set(jlistModel.lastIndexOf(jlistModel.lastElement()));
        }
    }

    class ShowListener {
        private JLabel selectedItemLabel;
        private JButton nextButton, previousButton;
        private JButton lastClickedShowButton;
        private final int maximumElementsPage;

        ShowListener(int maximumElementsPage) {
            this.maximumElementsPage = maximumElementsPage;
        }

        private void initJList(int begin, int end) {
            if (!jlistModel.isEmpty()) jlistModel.removeAllElements();

            IntStream.range(begin, end).forEach(index ->
                    jlistModel.addElement(selectedAndroidsList.get(index)));
            lastIndex.set(end - 1);

            if (previousButton != null) previousButton.setEnabled(lastIndex.get() - maximumElementsPage > 0);
            if (nextButton != null) nextButton.setEnabled(lastIndex.get() != selectedAndroidsList.size() - 1);
        }

        public void showJList(JButton clickedButton,
                              ArrayList<Android> arrayList,
                              String selectedItem) {
            clickedButton.setEnabled(false);
            if (lastClickedShowButton != null)
                lastClickedShowButton.setEnabled(true);
            lastClickedShowButton = clickedButton;

            if (selectedItemLabel != null)
                selectedItemLabel.setText(selectedItem);
            selectedAndroidsList = arrayList;

            int end = Math.min(maximumElementsPage, selectedAndroidsList.size());
            initJList(0, end);
        }

        public void installNextButtonListener(JButton nextButton) {
            nextButton.addActionListener(e -> {
                int selectedListSize = selectedAndroidsList.size();
                int newFirstIndex = lastIndex.get() + 1;
                int end = Math.min(selectedListSize, newFirstIndex + maximumElementsPage);
                initJList(newFirstIndex, end);
            });
            this.nextButton = nextButton;
        }

        public void installPreviousButtonListener(JButton previousButton) {
            previousButton.addActionListener(e -> {
                int modelSize = jlistModel.getSize();
                int lastPreviousIndex = lastIndex.get() - modelSize;
                int firstPreviousIndex = (lastPreviousIndex - maximumElementsPage) + 1;
                initJList(firstPreviousIndex, lastPreviousIndex + 1);
            });
            this.previousButton = previousButton;
        }

        public void setSelectedItemLabel(JLabel selectedItemLabel) {
            this.selectedItemLabel = selectedItemLabel;
        }
    }

}
