import java.util.ArrayList;
import java.util.Map;
import java.util.Random;
import java.util.stream.IntStream;

public class WorkProceeding {

    public static void pickRandomItem(ArrayList<Resource> resources, double power) {
        int resourcesListSize = resources.size();
        int maxValues = randomNumberInRange(resourcesListSize);
        IntStream.range(0, maxValues).forEach(element->{
            Resource resource = resources.get(randomNumberInRange(resourcesListSize));
            double newValue = resource.getValue() + (power/resource.difficulty);
            resource.setValue(newValue);
            resource.resLabel.setText(String.valueOf((int) newValue));
        });
    }

    public static int randomNumberInRange(int maxSize){
        Random rand = new Random();
        return rand.nextInt(maxSize);
    }

    public static void converseItem(Resource product, double power) {
        if (!isReadyToCraft(product)) return;
        product.sourcePairs.forEach((source, valueNeed) -> {
            double previousSourceValue = source.value;
            double currentSourceValue = previousSourceValue - (double) (valueNeed / product.difficulty);
            source.setValue(currentSourceValue);
            source.getResLabel().setText(String.valueOf((int) currentSourceValue));
        });
        double previousProductValue = product.value;
        double currentProductValue = previousProductValue + power / product.difficulty;
        product.setValue(currentProductValue);
        product.resLabel.setText(String.valueOf((int) currentProductValue));
    }

    private static boolean isReadyToCraft(Resource product) {
        Map<Resource, Integer> sources = product.sourcePairs;
        return sources.entrySet().stream().allMatch((entry) -> {
            Resource source = entry.getKey();
            double resValueNow = source.getValue();
            return resValueNow >= entry.getValue();
        });
    }


}
