import java.io.Serializable;
import java.util.*;

public class DataStorage implements Serializable {
    Map<String, Resource> resources;
    ArrayList<Android> free;
    //заменить на единый hashmap
    HashMap<String, ArrayList<Producer>> producers;
   // ArrayList<Producer> producers;

    private DataStorage() {
    }

    public static DataStorage getInstance() {
        return DataStorageHolder.dataStorageInstance;
    }

    private static class DataStorageHolder {
        private static final DataStorage dataStorageInstance = new DataStorage();
    }

    public void createFirstResources() {
        resources = new HashMap<>();
        resources.put("wires", new Resource()
                .setDifficulty(2));
        resources.put("nuts", new Resource()
                .setDifficulty(2));
        resources.put("metal flowers", new Resource()
                .setDifficulty(10));
        //productItems.add(new ResourcesWrapper("energy", energyCount));

        resources.put("cpu", new Resource()
                .setSource(Map.of(resources.get("wires"), 2,
                        resources.get("nuts"), 1))
                .setDifficulty(10));
        resources.put("rotor", new Resource()
                .setSource(Map.of(resources.get("metal flowers"), 3,
                        resources.get("nuts"), 1))
                .setDifficulty(10));
    }

    public void createManualJobs() {
        free = new ArrayList<>();

        ArrayList<Producer> garbageProducers = new ArrayList<>();
        garbageProducers.add(new MultipleTasksProducer("garbagers",
                setResourcesList("wires, nuts")));

        ArrayList<Producer>flowerProducers = new ArrayList<>();
        flowerProducers.add(new MultipleTasksProducer("gardeners",
                setResourcesList("metal flowers")));

        ArrayList<Producer>mechanismProducers = new ArrayList<>();
        mechanismProducers.add(new SingleTaskProducer("cpu makers", resources.get("cpu")));
        mechanismProducers.add(new SingleTaskProducer("rotor makers", resources.get("rotor")));

        //ArrayList <Producer> alchemists = new ArrayList<>();

        producers = new HashMap<>();
        producers.put("garbage collectors", garbageProducers);
        producers.put("flowers collectors", flowerProducers);
        producers.put("mechanisms makers", mechanismProducers);
    }

    public ArrayList<Resource> setResourcesList(String resourcesString) {
        ArrayList<Resource> resourcesList = new ArrayList<>();
        String[] resourcesStrings = resourcesString.trim().split(", |,");
        Arrays.stream(resourcesStrings).forEach(string ->
                resourcesList.add(resources.get(string)));
        return resourcesList;
    }
}
