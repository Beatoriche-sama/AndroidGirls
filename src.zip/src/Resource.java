import javax.swing.*;
import java.util.Map;

public class Resource{
    int difficulty;
    double value;
    boolean isActive;
    Map<Resource, Integer> sourcePairs;
    JLabel resLabel;

    public Resource(JLabel resLabel) {
        this.resLabel = resLabel;
    }

    public Resource() {
        this.resLabel = new JLabel();
    }

    public Resource setSource(Map<Resource, Integer> sourcePairs) {
        this.sourcePairs = sourcePairs;
        return this;
    }

    public void setValue(double value) {
        this.value = value;
    }

    public double getValue() {
        return value;
    }

    public JLabel getResLabel() {
        return resLabel;
    }

    public void setActive(boolean active) {
        isActive = active;
    }

    public Resource setDifficulty(int difficulty) {
        this.difficulty = difficulty;
        return this;
    }
}
