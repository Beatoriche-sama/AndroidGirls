import javax.swing.*;
import javax.swing.border.MatteBorder;
import javax.swing.plaf.basic.BasicComboPopup;
import javax.swing.plaf.basic.ComboPopup;
import javax.swing.plaf.metal.MetalComboBoxUI;
import java.awt.*;

public class CustomComboBox extends JComboBox<String>{
    private AbstractButton arrowButton;
    private final JPopupMenu popupMenu;

    public CustomComboBox(JPopupMenu popupMenu) {
        this.popupMenu = popupMenu;
        popupMenu.setBorder(new MatteBorder(1, 1, 1, 1, Color.DARK_GRAY));
        setPrototypeDisplayValue("12345678901234567890");
        setUI(new EmptyComboBoxUI());
        setSelectedIndex(-1);

        for (Component comp : getComponents()) {
            if (comp instanceof AbstractButton) {
                arrowButton = (AbstractButton) comp;
            }
        }

        arrowButton.addActionListener(event -> setPopupVisible(!popupMenu.isVisible()));
    }

    /*
     * Toggle the visibility of the custom popup.
     */
    public void setPopupVisible(boolean visible) {
        if (visible) {
            popupMenu.show(this, 0, getSize().height);
            popupMenu.setPopupSize(getWidth(), popupMenu.getHeight());

        } else {
            popupMenu.setVisible(false);
        }
    }

    /*
     * Hide real UI.
     */
    static class EmptyComboBoxUI extends MetalComboBoxUI {
        @Override
        protected ComboPopup createPopup() {
            BasicComboPopup thePopup = (BasicComboPopup) super.createPopup();
            thePopup.setPreferredSize(new Dimension(0, 0));
            return thePopup;
        }

    }

}
