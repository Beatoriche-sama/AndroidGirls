import javax.swing.*;
import java.util.ArrayList;
import java.util.function.Consumer;

public abstract class Producer {
    String producerName;
    int objectsNumber, power;
    ArrayList<Android> workers;

    public Producer() {
        this.workers = new ArrayList<>();
    }

    public double getAndroidPower() {
        return workers.stream().mapToInt(Android::getPower).sum();
    }

    public abstract void work();
}
