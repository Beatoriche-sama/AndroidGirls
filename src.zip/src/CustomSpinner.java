import javax.swing.*;
import javax.swing.plaf.basic.BasicSpinnerUI;
import javax.swing.text.DefaultFormatter;
import java.util.ArrayList;
import java.util.stream.IntStream;

public class CustomSpinner extends JSpinner {
    GroupNumberModel groupNumberModel;
    private final JLabel freeLabelCount;
    private final ArrayList<Android> jobList, freeList;
    int prevValue;
    JFormattedTextField defaultEditor;

    public CustomSpinner(BasicSpinnerUI ui, ArrayList<Android> jobList,
                         GroupNumberModel groupNumberModel) {
        this.freeLabelCount = groupNumberModel.getFreeLabelCount();
        this.jobList = jobList;
        this.freeList = groupNumberModel.getFreeList();
        this.groupNumberModel = groupNumberModel;
        groupNumberModel.addSpinner(this);
        SpinnerNumberModel model = new SpinnerNumberModel(jobList.size(), 0, null, 1);
        setModel(model);
        setUI(ui);
        defaultEditor = ((DefaultEditor) getEditor()).getTextField();
        defaultEditor.setHorizontalAlignment(JTextField.CENTER);
        defaultEditor.setColumns(4);
        ((DefaultFormatter) defaultEditor.getFormatter()).setAllowsInvalid(false);

        addChangeListener(e -> {
            int currentValue = (Integer) model.getValue();
            int freeSize = freeList.size();
            boolean isChangeAvailable = freeSize != 0 | currentValue < prevValue;
            if (isChangeAvailable) {
                updateSpinner(currentValue);
            }
        });
    }

    private void updateSpinner(int currentValue) {
        int prev = jobList.size();
        int valueJobDiff;
        if (prev == currentValue) {
            return;
        } else {
            valueJobDiff = prev - currentValue;
        }
        boolean isHire = valueJobDiff < 0;

        ArrayList<Android> toList, fromList;
        if (isHire) {
            toList = jobList;
            fromList = freeList;
        } else {
            toList = freeList;
            fromList = jobList;
        }

        DefaultListModel<Android> jlistModel = groupNumberModel.getJlistModel();
        IntStream.range(0, Math.abs(valueJobDiff)).forEach(index -> {
                    Android android = fromList.get(index);
                    fromList.remove(android);
                    toList.add(android);
                    if (jlistModel.contains(android)) jlistModel.removeElement(android);
                }
        );

        freeLabelCount.setText(String.valueOf(freeList.size()));
        //Collections.sort(arraylist, Collections.reverseOrder());
        prevValue = jobList.size();
    }

    @Override
    public void setValue(Object value) {
        int currentValue, valueToInt;
        valueToInt = (Integer) value;
        int freeSize = freeList.size();
        currentValue = valueToInt;
        int commonValue = groupNumberModel.getCommonValue();
        boolean overflow = (commonValue - prevValue) + currentValue > commonValue + freeSize;
        if (overflow) {
            currentValue = freeSize + prevValue;
            defaultEditor.setValue(currentValue);
        }
        super.setValue(currentValue);
    }

    @Override
    public Object getNextValue() {
        if (freeList.size() > 0) {
            return super.getNextValue();
        } else {
            return null;
        }
    }

    public ArrayList<Android> getJobList() {
        return jobList;
    }
}

