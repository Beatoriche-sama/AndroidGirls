import javax.swing.*;
import java.util.Arrays;

public class SelectDeselectListModel extends DefaultListSelectionModel {
    JMenu [] jMenus;

    public SelectDeselectListModel(JMenu [] jmenus){
        this.jMenus = jmenus;
    }

    private void checkEmptySelection(){
        if(getSelectedItemsCount() == 0)
            Arrays.stream(jMenus).forEach(jMenu -> jMenu.setEnabled(false));
    }

    private void enableMenus(){
        if(!jMenus[0].isEnabled())
        Arrays.stream(jMenus).forEach(jMenu -> jMenu.setEnabled(true));
    }

    @Override
    public void setSelectionInterval(int index0, int index1) {
        if (index0 == index1) {
            if (isSelectedIndex(index0)) {
                removeSelectionInterval(index0, index0);
                //checkEmptySelection();
                return;
            }
        }
        super.setSelectionInterval(index0, index1);
       // enableMenus();
    }

    @Override
    public void addSelectionInterval(int index0, int index1) {
        if (index0 == index1) {
            if (isSelectedIndex(index0)) {
                removeSelectionInterval(index0, index0);
                return;
            }
            super.addSelectionInterval(index0, index1);
            //enableMenus();
        }
    }

    @Override
    public void removeSelectionInterval(int index0, int index1) {
        super.removeSelectionInterval(index0, index1);
       // checkEmptySelection();
    }
}
