import net.miginfocom.swing.MigLayout;

import javax.swing.*;
import javax.swing.plaf.basic.BasicSpinnerUI;
import java.awt.*;

class LeftRightSpinnerUI extends BasicSpinnerUI {

    @Override
    protected Component createNextButton() {
        Component nextButton = new JButton("+");
        nextButton.setName("Spinner.nextButton");
        installNextButtonListeners(nextButton);
        return nextButton;
    }

    @Override
    protected Component createPreviousButton() {
        Component previousButton = new JButton("-");
        previousButton.setName("Spinner.previousButton");
        installPreviousButtonListeners(previousButton);
        return previousButton;
    }


    @Override
    public void installUI(JComponent c) {
        super.installUI(c);
        c.removeAll();
        c.setLayout(new MigLayout("flowx"));
        c.setBackground(null);
        c.setBorder(null);
        c.add(createPreviousButton());
        c.add(createEditor());
        c.add(createNextButton());
    }
}
