import javax.swing.*;
import java.util.ArrayList;

public interface MenuItemListener {
    void setListener(JMenuItem menuItem, ArrayList<Android> list);
}

