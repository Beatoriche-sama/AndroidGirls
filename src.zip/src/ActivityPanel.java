import net.miginfocom.swing.MigLayout;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.HashMap;


public class ActivityPanel extends JPanel {
    int listSize;
    ArrayList<Android> freeList;
    HashMap<String, ArrayList<Producer>> producersMap;
    JMenu dismissMenu;
    Font guiFont;
    GroupNumberModel groupNumberModel;
    LeftRightSpinnerUI ui;
    JList<Android> jList;
    ListenersHolder.HireListener hireListener;
    ListenersHolder.ShowListener showListener;

    public ActivityPanel(int listSize,
                         ArrayList<Android> freeList,
                         HashMap<String, ArrayList<Producer>> producersMap) {
        this.listSize = listSize;
        this.freeList = freeList;
        this.producersMap = producersMap;
        groupNumberModel = new GroupNumberModel();
        groupNumberModel.setFreeList(freeList);

        jList = new JList<>();
        DefaultListModel<Android> jlistModel = new DefaultListModel<>();
        jList.setModel(jlistModel);
        jList.setCellRenderer(new PanelRenderer());
        groupNumberModel.setJlistModel(jlistModel);

        ListenersHolder listenersHolder = new ListenersHolder(jList);
        this.hireListener = listenersHolder.createHireListener(groupNumberModel);
        this.showListener = listenersHolder.createShowListener(listSize);

        setLayout(new MigLayout("flowx, fill"));
        add(createFactoriesPanel(), "grow");
        add(createAndroidsListPanel(), "grow");
    }

    private JPanel createAndroidsListPanel() {
        JPanel androidListPanel = new JPanel();
        androidListPanel.add(createMenuBar(), "north");

        //поменять
        jList.setSelectionModel(new SelectDeselectListModel(new JMenu[]{dismissMenu}));

        JButton previousButton = new JButton("Previous " + listSize);
        JButton nextButton = new JButton("Next " + listSize);
        showListener.installPreviousButtonListener(previousButton);
        showListener.installNextButtonListener(nextButton);
        previousButton.setEnabled(false);
        nextButton.setEnabled(false);

        JLabel selectedItemLabel = new JLabel();
        showListener.setSelectedItemLabel(selectedItemLabel);

        androidListPanel.setLayout(new MigLayout("fillx, insets 0, flowy"));
        androidListPanel.setBackground(Color.white);
        androidListPanel.add(previousButton, "split 2, flowx, hidemode 3");
        androidListPanel.add(nextButton, "flowy, hidemode 3");
        androidListPanel.add(selectedItemLabel);
        androidListPanel.add(jList, "growx");
        return androidListPanel;
    }

    private JPanel createFactoriesPanel() {
        JPanel factoriesPanel = new JPanel();
        guiFont = new Font("Serif", Font.BOLD, 16);
        factoriesPanel.setLayout(new MigLayout("flowy, fillx"));
        factoriesPanel.setBackground(null);

        JLabel freeLabel = new JLabel("free");
        JLabel freeLabelCount = new JLabel(String.valueOf(freeList.size()));
        freeLabel.setFont(guiFont);

        JButton showFreeList = new JButton("Show free androids");
        showFreeList.addActionListener(e -> showListener.showJList(showFreeList, freeList, "free"));
        factoriesPanel.add(freeLabel, "split 3, flowx, center");
        factoriesPanel.add(freeLabelCount);
        factoriesPanel.add(showFreeList);

        ui = new LeftRightSpinnerUI();
        groupNumberModel.setFreeLabelCount(freeLabelCount);

        JPanel buttonsBar = new JPanel();
        JPanel producersListPanel = new JPanel();
        producersListPanel.setBackground(null);
        producersMap.forEach((categoryName, producerList) -> {
            JButton showProducers = new JButton(categoryName);
            showProducers.addActionListener(e -> {
                producersListPanel.removeAll();
                producerList.forEach(producer->
                        producersListPanel.add(createProducerPanel(producer)));
                producersListPanel.revalidate();
            });
            buttonsBar.add(showProducers);
        });
        factoriesPanel.add(buttonsBar);
        factoriesPanel.add(producersListPanel);
        return factoriesPanel;
    }

    private JPanel createProducerPanel(Producer producer){
        JPanel jobPanel = new JPanel();
        jobPanel.setLayout(new MigLayout("flowy"));
        jobPanel.setBorder(BorderFactory.createLineBorder(Color.black));

        JLabel taskLabel = new JLabel(producer.producerName);
        taskLabel.setFont(guiFont);
        CustomSpinner spinner = new CustomSpinner(ui, producer.workers, groupNumberModel);

        JButton hireButton = new JButton("Hire selected");
        hireButton.addActionListener(e ->
                hireListener.setActivity(producer.workers));
        JButton showButton = new JButton("Show producers");
        showButton.addActionListener(e ->
                showListener.showJList(showButton, producer.workers, producer.producerName));

        jobPanel.add(taskLabel, "split 2, flowx, center");
        jobPanel.add(spinner);
        jobPanel.add(showButton, "split 2, flowy, right");
        jobPanel.add(hireButton, "right");
        return jobPanel;
    }

    private JMenuBar createMenuBar() {
        JMenuBar menuBar = new JMenuBar();
        dismissMenu = new JMenu("Dismiss selected");
        JMenu pickFilterMenu = new JMenu("Pick filter");
        dismissMenu.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                hireListener.setActivity(freeList);
            }
        });
        menuBar.add(dismissMenu);
        menuBar.add(pickFilterMenu);
        return menuBar;
    }
}
